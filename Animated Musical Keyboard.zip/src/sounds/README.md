Neuronal Synchrony
==================

A collection of two dimensional animations that are triggered by sound.

(c) 2012 - 2013 [jonobr1](http://jonobr1.com/). Freely distributed under the [MIT License](http://opensource.org/licenses/MIT).

Prototyped with [Processing](http://processing.org/), built with [JavaScript](http://jonobr1.github.com/two.js).